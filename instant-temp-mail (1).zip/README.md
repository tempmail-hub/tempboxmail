# Instant Temp Mail

A simple static landing page for an instant temporary email service. Redirects users to [TempBoxMail](http://tempboxmail.com/) to generate anonymous email addresses.

## Features
- Clean, responsive HTML/CSS layout
- Direct link to temp mail service
- MIT licensed and ready to use

## Reference
This project links directly to the original service [TempBoxMail](http://tempboxmail.com/) for instant temporary email addresses.
